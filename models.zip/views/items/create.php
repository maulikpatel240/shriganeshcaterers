<?= $this->render('_form', [
        'model' => $model,
        'modelItems' => $modelItems,
    ]) ?>